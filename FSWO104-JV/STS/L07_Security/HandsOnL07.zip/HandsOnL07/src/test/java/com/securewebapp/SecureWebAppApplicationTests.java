package com.securewebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
